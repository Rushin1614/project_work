<?php
$conn = new mysqli('localhost', 'root','', 'logindb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = "UPDATE delivery SET status=1 WHERE id='$id'";
    $conn->query($sql);
}
if (isset($_GET['eid'])){
    $id=$_GET['eid'];
    $sql = "DELETE FROM delivery WHERE id='$id'";
    $conn->query($sql);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>
        Feed
    </title>
    <link rel="Stylesheet" href="delivery.css">
    <style>

    </style>
</head>
<body style="height: auto">
<div style="display : grid; grid-template-columns: 25% 75%;">

    <div>
        <img class="Menu"  style="width: 77%" src="pics\feed\left.png">
        <img class="logo"  src="pics\logo.png">
        <img class="line"  src="pics\feed\line.png">
        <label class="Menu1">Menu</label>

        <div>
            <button class="Feed" style="background-color: #c5ebbc">To Do</button>
            <img class="Feed1"  src="pics/feed/todo.png">
            <button class="Bidding" style="background-color: #c5ebbc">Doing</button>
            <img class="Bidding1"  src="pics/feed/doing.png">
            <a href="done.php"><button class="Wishlist" style="background-color: #c5ebbc">Done</button></a>
            <img class="Wishlist1"  src="pics/feed/done.png">
            <button class="Requests" style="background-color: #c5ebbc">Fee</button>
            <img class="Requests1"  src="pics/feed/fee.png">

            <img class="line1"  src="pics\feed\line.png">
            <label class="Message">Message</label>

        </div>
        <div style="background-color:rgb(244, 238, 238); width: 290px; height:280px; border: 1px solid rgb(16, 17, 16); padding: 50px; margin-top: -310px; position:absolute">
            <img class="man1" style="width: 30px;height: 30px;right: 40px;bottom: 40px;border-radius: 50%" src="pics/man1.png">
            <p class="nam1" style="position: relative;width: 70%;/* height: 70px; */left: 20px;bottom: 68px;color:  rgb(11, 12, 13);font-size: 16px;font-family: Poppins;">Vimukthi Dulnath</p><br>

            <img class="man2" style="width: 30px;height: 30px;right: 40px;bottom: 50px;border-radius: 50%" src="pics/man2.png">
            <p class="nam2" style="position: relative;width: 70%;/* height: 70px; */left: 20px;bottom: 77px;color:  rgb(11, 12, 13);font-size: 16px;font-family: Poppins;">Praneeth Silva</p><br>

            <img class="man3" style="width: 30px;height: 30px;right: 40px;bottom: 60px;border-radius: 50%" src="pics/man3.png">
            <p class="nam3"style="position: relative;width: 70%;/* height: 70px; */left: 20px;bottom: 88px;color:  rgb(11, 12, 13);font-size: 16px;font-family: Poppins;">Rushin Sandeepana</p><br>

            <img class="man4" style="width: 30px;height: 30px;right: 40px;bottom: 70px;border-radius: 50%" src="pics/man4.png">
            <p class="nam4" style="position: relative;width: 70%;/* height: 70px; */left: 20px;bottom: 98px;color:  rgb(11, 12, 13);font-size: 16px;font-family: Poppins;">Janith Hesara</p>
        </div>







    </div>


    <div style="display : grid; grid-template-rows: 10% 90%;">
        <div>
            <img class="top"  src="pics\feed\top.png">
            <input class="Search" type="textbox" placeholder="Search" style="padding-left: 60px">
            <img class="Search1"  src="pics\feed\search.png" style="margin-bottom: 30px;">
            <img class="bell" src="pics\feed\bell.png">
            <img class="active" src="pics\feed\active.png">
            <img class="profile" src="pics\feed\profilepic.png">
        </div>


        <div>
            <div class="Scroll-div">
                <div class="scroll-object">

                <?php
                    $sql = "SELECT * FROM delivery WHERE status=0";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) { ?>
                    <?php while($row = $result->fetch_assoc()) { ?>
                    <div class="container" style="margin-top: 20px; width:850px">

                        <div class="item item-1" style="height: 90px">
                            <img class="profile-pic" src="/pics/man1.png">
                            <p class="nam"><?php echo  $row['buyer'] ?></p><br>
                            <p class="date"><?php echo date('d F y', strtotime($row['date'])) ?></p>

                        </div>
                        <div class="item item-2" style="height: 200px">
                            <h2 class="head">&nbsp<?php echo  $row['buyer'] ?>&nbsp wants to deliver&nbsp<?php echo  $row['item'] ?>&nbspin&nbsp<?php echo  $row['quantity'] ?>&nbspKgs&nbsp<br>from <?php echo  $row['fro'] ?>&nbsp to <?php echo  $row['too'] ?>&nbsp</h2>

                            <table class="table" style="width:70%">

                                <tr>
                                    <td>Item:</td>
                                    <td><font color="#0C7417"><?php echo  $row['item'] ?></td>
                                </tr>

                                <tr>
                                    <td>Amount:</td>
                                    <td><font color="#0C7417"><?php echo $row['amount']; ?></td>
                                </tr>


                                <tr>
                                    <td>From:</td>
                                    <td><font color="#0C7417"><?php echo $row['fro']; ?></td>
                                </tr>


                                <tr>
                                    <td>To:</td>
                                    <td font color="#0C7417"><?php echo $row['too']; ?></td>
                                </tr>


                                <tr>
                                    <td>Fee:</td>
                                    <td style="font color=#0C7417;"><?php echo  $row['fee'] ?></td>
                                </tr>

                                <tr>
                                    <td>Vehicle type:</td>
                                    <td style="color=#0C7417;"><?php echo  $row['vtype'] ?></td>
                                </tr>

                            </table>
                            <a href='todo.php?id=<?php echo $row['id'] ?>' class="Approve btn1">Approve</a>
                            <a href='todo.php?eid=<?php echo $row['id'] ?>'><button class="Discard btn2">Discard</button></a>

                        </div>
                    </div>

                        <?php } ?>
                    <?php } ?>

                </div>
            </div>

        </diV>




    </div>



</div>

</body>
</html>