<?php
$conn = new mysqli('localhost', 'root','', 'logindb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
<!DOCTYPE html>
<html>
  <head>
    <title>
     Feed
    </title>
    <link rel="Stylesheet" href="done.css">
    <style>
     
      </style>
  </head>
  <body style="height: auto">
  <div style="display : grid; grid-template-columns: 25% 75%;">

      <div>
          <img class="Menu"  src="pics\feed\left.png">
          <img class="logo"  src="pics\logo.png">
          <img class="line"  src="pics\feed\line.png">
          <label class="Menu1">Menu</label>

          <div>
              <a href="todo.php"><button class="Feed">To Do</button></a>
              <img class="Feed1"  src="pics/feed/todo.png">
              <button class="Bidding">Doing</button>
              <img class="Bidding1"  src="pics/feed/doing.png">
              <a href="done.php"><button class="Wishlist">Done</button></a>
              <img class="Wishlist1"  src="pics/feed/done.png">
              <button class="Requests">Fee</button>
              <img class="Requests1"  src="pics/feed/fee.png">
          </div>

          <img class="line1"  src="pics\feed\line.png">
          <label class="Message">Message</label>
          <div style="background-color:rgb(244, 238, 238); width: 290px; height:280px; border: 1px solid rgb(16, 17, 16); padding: 50px; margin-top: 500px; position:absolute">
              <img class="man1" src="pics/man1.png">
              <p class="nam1">Vimukthi Dulnath</p><br>

              <img class="man2" src="pics/man2.png">
              <p class="nam2">Praneeth Silva</p><br>

              <img class="man3" src="pics/man3.png">
              <p class="nam3">Rushin Sandeepana</p><br>

              <img class="man4" src="pics/man4.png">
              <p class="nam4">Janith Hesara</p>
          </div>


      </div>


      <div style="display : grid; grid-template-rows: 10% 90%;">
          <div>
              <img class="top"  src="pics\feed\top.png">
              <input class="Search" type="textbox" placeholder="Search">
              <img class="Search1"  src="pics\feed\search.png">
              <img class="bell" src="pics\feed\bell.png">
              <img class="active" src="pics\feed\active.png">
              <img class="profile" src="pics\feed\profilepic.png">
          </div>
          <div>
              <div class="Scroll-bar>
                <?php
              $sql = "SELECT * FROM delivery WHERE status=1";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) { ?>
                    <?php while($row = $result->fetch_assoc()) { ?>

              <div class="container" style="margin-top: 70px;width: 850px;height: 300px;">
                  <div class="item item-1" style="height: 90px">
                      <img class="profile-pic" src="/pics/man1.png">
                      <p class="nam"><?php echo  $row['buyer'] ?></p><br>
                      <p class="date"><?php echo date('d F y', strtotime($row['date'])) ?></p>
                  </div>
                  <div class="item item-2" style="height: 200px">
                      <h2 class="head">&nbsp<?php echo  $row['buyer'] ?>&nbsp has successfully delivered&nbsp<?php echo  $row['item'] ?>&nbspin&nbsp<?php echo  $row['quantity'] ?>&nbspKgs&nbsp<br>from <?php echo  $row['fro'] ?>&nbsp to <?php echo  $row['too'] ?>&nbsp</h2>

                      <table class="table" style="width:70%">

                          <tr>
                              <td>Item:</td>
                              <td><font color="#0C7417"><?php echo  $row['item'] ?></td>
                          </tr>

                          <tr>
                              <td>Amount:</td>
                              <td><font color="#0C7417"><?php echo  $row['amount'] ?></td>
                          </tr>


                          <tr>
                              <td>From:</td>
                              <td><font color="#0C7417"><?php echo  $row['fro'] ?></td>
                          </tr>


                          <tr>
                              <td>To:</td>
                              <td><font color="#0C7417"><?php echo  $row['too'] ?></td>
                          </tr>

                          <tr>
                              <td>Fee:</td>
                              <td><style="font color="#0C7417""><?php echo  $row['fee'] ?></td>
                          </tr>
                          <tr>
                              <td>Vehicle Type:</td>
                              <td><font color="#0C7417"><?php echo  $row['vtype'] ?></td>
                          </tr>

                      </table>
                      <button class="Discard btn2" style="margin-top: -120px;padding-left: 35px">Done</button>
                      <button class="Discard" style="margin-top: -60px;">Delete</button>
                  </div>
              </div>
          <?php } ?>
          <?php } ?>
        </div>
  </div>
  </div>
</body>
</html>