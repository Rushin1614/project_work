<?php
 if(isset($_))




?>


<!DOCTYPE html>
<html>
  <head>
    <title>
     Feed
    </title>
    <link rel="Stylesheet" href="delivery.css">
    <style>
     
      </style>
  </head>
  <body>
    <div style="display : grid; grid-template-columns: 25% 75%;">

          <div> 
                    <img class="Menu"  src="pics\feed\left.png">
                    <img class="logo"  src="pics\logo.png">
                    <img class="line"  src="pics\feed\line.png">
                    <label class="Menu1">Menu</label>

                    <div> 
                        <a href="todo.php" onclick="hello()"><button class="Feed">To Do</button></a>
                      <img class="Feed1"  src="pics/feed/todo.png">
                      <button class="Bidding">Doing</button>
                      <img class="Bidding1"  src="pics/feed/doing.png">
                      <a href="done.php"><button class="Wishlist">Done</button></a>
                      <img class="Wishlist1"  src="pics/feed/done.png">
                      <button class="Requests">Fee</button>
                      <img class="Requests1"  src="pics/feed/fee.png">
                    </div>

                    <img class="line1"  src="pics\feed\line.png">
                    <label class="Message">Message</label>
                  

          </div>


          <div style="display : grid; grid-template-rows: 10% 90%;">
                  <div>
                          <img class="top"  src="pics\feed\top.png"> 
                          <input class="Search" type="textbox" placeholder="Search">
                          <img class="Search1"  src="pics\feed\search.png">
                          <img class="bell" src="pics\feed\bell.png">
                          <img class="active" src="pics\feed\active.png"> 
                          <img class="profile" src="pics\feed\profilepic.png"> 
                  </div>


                  <diV>
                          <div class="Scroll-bar">
<!--                            <div class="container">-->
<!--                              <div class="item item-1">-->
<!--                                <img class="profile-pic" src="/pics/man1.png">-->
<!--                                <p class="nam">Pamith Welikala</p><br>-->
<!--                                <p class="date">3 September 2022</p>-->
<!---->
<!--                              </div>-->
<!--                              <div class="item item-2">-->
<!--                                <h2 class="head">Pamith Welikala wants to deliver papaya in 2KG (s) <br>from Godagama to Thalawathugoda</h2>-->
<!---->
<!--                                <table class="table" style="width:70%">-->
<!--  -->
<!--                                  <tr>-->
<!--                                    <td>Item:</td>-->
<!--                                    <td><font color="#0C7417">Papaya</td>-->
<!--                                  </tr>-->
<!---->
<!--                                  <tr>-->
<!--                                    <td>Amount:</td>-->
<!--                                    <td><font color="#0C7417">2KG</td> -->
<!--                                  </tr>-->
<!---->
<!--                                  -->
<!--                                  <tr>-->
<!--                                    <td>From:</td>-->
<!--                                    <td><font color="#0C7417">101, 1st lane, Rathmaldeniya, Godagama, Colombo</td> -->
<!--                                  </tr>-->
<!---->
<!--                                  -->
<!--                                  <tr>-->
<!--                                    <td>To:</td>-->
<!--                                    <td><font color="#0C7417">53/A, Samagi Mawatha, Thalawathugoda, Colombo</td> -->
<!--                                  </tr>-->
<!---->
<!--                                  -->
<!--                                  <tr>-->
<!--                                    <td>Fee:</td>-->
<!--                                    <td><font color="#0C7417">RS. 350.00</td> -->
<!--                                  </tr>-->
<!---->
<!--                                  -->
<!--                                  <tr>-->
<!--                                    <td>Vehicle Type:</td>-->
<!--                                    <td><font color="#0C7417">Motorcycle / Three wheeler</td> -->
<!--                                  </tr>-->
<!--                                </table>-->
<!---->
<!--                                <button class="Approve btn1">Approve</button>-->
<!--                                <button class="Discard btn2">Discard</button>-->
<!---->
<!--                              </div>-->
<!--                            </div>-->
<!--                          </div>-->

                  </diV>
                  
    


          </div>
         
                   

    </div>
    <script>
        function hello(){
            
        }
    </script>

  </body>
</html>