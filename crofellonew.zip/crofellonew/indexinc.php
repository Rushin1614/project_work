<?php
$password = $_POST['password'];
$email = $_POST['email'];
$conn = new mysqli('localhost', 'root','', 'logindb');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM user WHERE email='$email'";
$result = $conn->query($sql);
if($result->num_rows>0){

    while($row = $result->fetch_assoc()) { ?>
        <?php $pass = $row['password_hash'];
        if(password_verify($password,$pass)){
            header("Location: todo.php");
        }else{ ?>

       <?php } ?>
    <?php } ?>
<?php } ?>
