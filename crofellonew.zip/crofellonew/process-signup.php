<?php
if (empty($_POST["fname"])) {
    die("Name is required");
}

if (empty($_POST["lname"])) {  //aluthen demma
    die("Name is required");
}

if (empty($_POST["vnum"])) {  //aluth ekak
    die("Vehicle number is required");
}

if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
    die("Valid email is required");
}

if (strlen($_POST["password"]) < 8) {
    echo $_POST["password"];

    die("password must be at least 8 characters");
}

if (!preg_match("/[a-z]/i", $_POST["password"])) {
    die("password must contain at least one letter");
}

if (!preg_match("/[0-9]/", $_POST["password"])) {
    die("Password must contain at least one number");
}

$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$vnumber = $_POST['vnum'];
$email = $_POST['email'];
$mysqli = require __DIR__ . "/database.php";


$sql = "INSERT INTO user (fname , lname , vnumber, email, password_hash)
        VALUES ('$fname', '$lname', '$vnumber', '$email', '$password_hash')";

$stmt = $mysqli->stmt_init();

if (!$stmt->prepare($sql)) {
    die("SQL error: " . $mysqli->error);
}

if ($stmt->execute()) {

    header("Location: index.php");
    exit;

}else {
    if ($mysqli->errno === 1062) {
        die("email already taken");
    } else {
        die ($mysqli->error . "  " . $mysqli->errno);
    }
}